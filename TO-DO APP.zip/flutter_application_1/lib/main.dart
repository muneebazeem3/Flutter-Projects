import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To-Do App',
      theme: ThemeData(
        primarySwatch: const Color.fromARGB(255, 33, 100, 243),
      ),
      home: TodoScreen(),
    );
  }
}

class TodoScreen extends StatefulWidget {
  @override
  _TodoScreenState createState() => _TodoScreenState();
}

class _TodoScreenState extends State<TodoScreen> {
  // Hardcoded list of tasks
  final List<TodoItem> _tasks = [
    TodoItem(task: 'Go Home by 6pm', isChecked: false),
    TodoItem(task: 'hit the gym', isChecked: false),
    TodoItem(task: 'play badminton with friends', isChecked: false),
    TodoItem(task: 'Call mom', isChecked: true), // Example of a completed task
  ];

  // Function to toggle the check box of a task
  void _toggleTask(int index) {
    setState(() {
      _tasks[index].isChecked = !_tasks[index].isChecked;
    });
  }

  // Function to remove completed tasks
  void _removeCompletedTasks() {
    setState(() {
      _tasks.removeWhere((task) => task.isChecked);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('To-Do List'),
        actions: [
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: _removeCompletedTasks,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Display the list of tasks
            Expanded(
              child: ListView.builder(
                itemCount: _tasks.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: Checkbox(
                      value: _tasks[index].isChecked,
                      onChanged: (bool? value) {
                        _toggleTask(index);
                      },
                    ),
                    title: Text(
                      _tasks[index].task,
                      style: TextStyle(
                        decoration: _tasks[index].isChecked
                            ? TextDecoration.lineThrough
                            : null,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TodoItem {
  String task;
  bool isChecked;

  TodoItem({required this.task, required this.isChecked});
}
